#include <stdio.h>
#include <string.h>

#define WAV_HEADER_SIZE 44

typedef struct {
	int	sampleRate;
	int	nChannels;
	long	nSamples;
} WavInfo;

inline FILE* AuChannelOpen (const char* filename, WavInfo* info)
{
	unsigned char header[WAV_HEADER_SIZE];
	FILE *handle;
	
	if (!strcmp(filename,"-"))
		handle = stdin;
	else
		handle = fopen(filename, "rb");

	if(!handle)
		return NULL;

	if(fread(header, 1, WAV_HEADER_SIZE, handle) != WAV_HEADER_SIZE)
		return NULL;

	info->nSamples		= (header[4] | (header[5] << 8) | (header[6] << 16) | (header[7] << 24)) + 8;
	info->nChannels		= header[22] | header[23] << 8;
	info->sampleRate	= header[24] | header[25] << 8 | header[26] << 12 | header[27] << 16;
	return handle;
}

inline void AuChannelClose (FILE *audioChannel)
{
	fclose(audioChannel);
}

inline size_t AuChannelReadShort(FILE *audioChannel, short *samples, int nSamples, int *readed)
{
	*readed = fread(samples, 2, nSamples, audioChannel);
	return *readed <= 0;
}
